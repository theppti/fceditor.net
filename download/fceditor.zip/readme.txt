  FCEditor .NET 

  Flow chart generator.

  Features:

- import from C#, Pascal
- code changing and reparse them
- show code sintax error
- export fc to different graphic format


  contact:

e-mail: fceditor.net@gmail.com 
ICQ:    332-753-297
Web:    www.fceditor.com
